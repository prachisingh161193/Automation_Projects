package testNG;

import org.testng.annotations.Test;

import KDT_framework.OperationalClass;

import org.testng.annotations.BeforeTest;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class MultipleTestCases
{
	WebDriver driver;
	
	
	@BeforeTest
	  public void beforeTest()
	{
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Kunal\\Documents\\Automation\\chromedriver-win32\\chromedriver.exe");
		driver= (WebDriver) new ChromeDriver();
		   driver.manage().window().maximize();
		   driver.manage().deleteAllCookies();
	  }
	
	/*@Test(priority=1)
		  public void Registration() throws Exception 
			{
				OperationalClass l= new OperationalClass();
				  l.url(driver);
			      l.maximize(driver);
			      l.cookies(driver);
			      Thread.sleep(2000);
			      l.newuser(driver);
		  }*/
	@Test(priority=2)
			  public void Signin() throws Exception 
				{
					OperationalClass l= new OperationalClass();
					  l.url(driver);
				      l.maximize(driver);
				      l.cookies(driver);
				      Thread.sleep(2000);
				      l.email(driver, "myselfparachi@gmail.com");
				      l.password(driver, "Family@143");
				      Thread.sleep(2000);
				      l.signinbutton(driver);
				     
			  }
	@Test(priority=3)
			  public void SearchForProduct() throws Exception 
				{
				String searchhere= JOptionPane.showInputDialog("Search Here");
				driver.findElement(By.id("search")).sendKeys(searchhere);
				driver.findElement(By.xpath("//button[@aria-label='Search']")).click();	
				//driver.findElement(By.partialLinkText("tops and tees")).click();
				Thread.sleep(2000);
				driver.findElement(By.id("option-label-size-143-item-170")).click();  	
				Thread.sleep(2000);
				driver.findElement(By.id("option-label-color-93-item-57")).click();
			  }
	@Test(priority=4)
			  public void AddToCart() throws Exception 
				{
				driver.findElement(By.xpath("//div[@class='products wrapper grid products-grid']//div[3]//div[1]//div[1]//form[1]")).click();
				Thread.sleep(2000);
				driver.findElement(By.xpath("//a[@class='action showcart']")).click();
				Thread.sleep(2000);
				driver.findElement(By.xpath("//a[@class='action edit']")).click();
				Thread.sleep(2000);
				driver.findElement(By.id("option-label-size-143-item-168")).click();  	
				Thread.sleep(2000);
				driver.findElement(By.id("option-label-color-93-item-56")).click();
				Thread.sleep(2000);
				//driver.findElement(By.id("qty")).sendKeys("2");
				Thread.sleep(2000);
				driver.findElement(By.id("product-updatecart-button")).click();
			  }
	@Test(priority=5)
	    
			  public void summary() throws Exception 
				{
				/*driver.findElement(By.xpath("//strong[@id='block-shipping-heading']")).click();
				 s = new Select(driver.findElement(By.xpath("//select[@name='country_id']")));
				 Thread.sleep(2000);
				 s.selectByVisibleText("India");
				 Thread.sleep(2000);
				 s = new Select(driver.findElement(By.xpath("//select[@name='region_id']")));
			     s.selectByIndex(16);
			   //  String zipcode= JOptionPane.showInputDialog("Zip/Postal Code");
			     driver.findElement(By.xpath("//input[@name='postcode']")).sendKeys(" ");*/
			     driver.findElement(By.xpath("//button[@data-role='proceed-to-checkout']")).click();
			     Thread.sleep(5000);
			  //   driver.findElement(By.xpath("//span[text()='Next']")).click();
			  }
	@Test(priority=6)
	
			  public void ShippingAddress() throws Exception 
				{
					/*driver.findElement(By.id("QODAC1D")).sendKeys("Puja");
			    	driver.findElement(By.id("WQJKFA6")).sendKeys("Kumari");
					 Thread.sleep(2000);
					driver.findElement(By.xpath("//input[@name='company']")).sendKeys("IBM");
				
					driver.findElement(By.xpath("//input[@name='street[0]']")).sendKeys("House no- 19");
					driver.findElement(By.xpath("//input[@name='street[1]']")).sendKeys("SamyathiHouse, 2nd cross");
					driver.findElement(By.xpath("//input[@name='street[2]']")).sendKeys("SilkBoard");
					driver.findElement(By.xpath("//input[@name='city']")).sendKeys("Bangalore");
					driver.findElement(By.xpath("//input[@name='telephone']")).sendKeys("7415166957");
					 Thread.sleep(2000);*/
					driver.findElement(By.xpath("//span[text()='Next']")).click();
					Thread.sleep(2000);
			  } 
@Test(priority=7)
			  public void ReviewAndPayment() throws Exception 
				{
				driver.findElement(By.xpath("//span[text()='Place Order']")).click();
				Thread.sleep(2000);
			  }
@Test(priority=8)
			public void welcomeAdmin() throws Exception 
			{
         	driver.findElement(By.xpath("//span[@aria-expanded='false']")).click();
         	Thread.sleep(2000);
         	}
@Test(priority=9)
			public void signout() throws Exception 
			{
				driver.findElement(By.partialLinkText("Sign")).click();
				Thread.sleep(2000);
			}
  @AfterTest
  public void afterTest() 
  {
	  driver.close();
  }

}
