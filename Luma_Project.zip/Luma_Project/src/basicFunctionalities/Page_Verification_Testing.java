package basicFunctionalities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Page_Verification_Testing 
{
	WebDriver driver;

	public void url(WebDriver driver)
	{
       driver.get("https://magento.softwaretestingboard.com");
	}
public void maximize(WebDriver driver)
    {
	  driver.manage().window().maximize();
    }
public void cookies(WebDriver driver)
	{
		driver.manage().deleteAllCookies();
	}
	public void pageverification() 
	{
		String title = driver.getTitle();
		System.out.println("Page title is:" + title);

		String expectedTitle = "Online Pet Shop & Supplies Store - Buy Pet Food & Accessories";

		if (title.equals(expectedTitle)) 
		{
			System.out.println("Test Passed!");
		} else {
			System.out.println("Test Failed");
		}
	}
	

	public static void main(String[] args) 
	{
		WebDriver driver=null;
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Kunal\\Documents\\Automation\\chromedriver-win32\\chromedriver.exe");
		driver = new ChromeDriver();

		
		Page_Verification_Testing p=new Page_Verification_Testing();

		

	}

}
