package basicFunctionalities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class URL_Testing 
{
	
		static WebDriver driver;
		String userurl="https://magento.softwaretestingboard.com";
		public void url(WebDriver driver)
		{
			
			driver.get(userurl);
		}
		public void maximize(WebDriver driver)
	    {
		  driver.manage().window().maximize();
	    }
		public void cookies(WebDriver driver)
		{
			driver.manage().deleteAllCookies();
		}
		public void urltest()
		{
			String actualurl=driver.getCurrentUrl();
			System.out.println("Current url" +actualurl);
			//Assert.assertEquals(actualurl,"https://petsworld.in/", "URL TEST IS SUCCESSFUL");
			if(actualurl.equals(userurl))
			{
				System.out.println("URL Testing passed");
			}else
			{
			System.out.println("URL testing failed");
			}
		}

			
	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Kunal\\Documents\\Automation\\chromedriver-win32\\chromedriver.exe");
		driver=new ChromeDriver();
		
		URL_Testing url=new URL_Testing();
		url.url(driver);
		url.maximize(driver);
		url.cookies(driver);
		url.urltest();

	}

}
