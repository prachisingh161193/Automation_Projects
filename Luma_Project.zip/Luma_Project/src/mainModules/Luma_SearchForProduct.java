package mainModules;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Luma_SearchForProduct {
	    
	public void url(WebDriver driver)
		{
	       driver.get("https://magento.softwaretestingboard.com");
		}
	public void maximize(WebDriver driver)
	    {
		  driver.manage().window().maximize();
	    }
	public void cookies(WebDriver driver)
		{
			driver.manage().deleteAllCookies();
		}
	public void newuser(WebDriver driver) throws InterruptedException
		{
			driver.findElement(By.partialLinkText("Create an")).click();
			driver.findElement(By.id("firstname")).sendKeys("Prachi");
			//Thread.sleep(2000);
			driver.findElement(By.id("lastname")).sendKeys("Singh");
			//Thread.sleep(2000);
			driver.findElement(By.id("email_address")).sendKeys("myselfparachi@gmail.com");
			//Thread.sleep(2000);
			driver.findElement(By.id("password")).sendKeys("Family@143");
			//Thread.sleep(2000);
			driver.findElement(By.id("password-confirmation")).sendKeys("Family@143");
		//	Thread.sleep(2000);
			driver.findElement(By.partialLinkText("Create an")).click();
		}
	public void signin(WebDriver driver) throws InterruptedException
		{
			driver.findElement(By.partialLinkText("Sign")).click();  
			driver.findElement(By.id("email")).sendKeys("myselfparachi@gmail.com");
			Thread.sleep(2000);
			driver.findElement(By.id("pass")).sendKeys("Family@143");
			Thread.sleep(2000);
			driver.findElement(By.id("send2")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//a[@aria-label='store logo']//img")).click();
		}
	public void searchhere(WebDriver driver, String search) throws InterruptedException 
	  {
		String searchhere= JOptionPane.showInputDialog("Search Here");
		driver.findElement(By.id("search")).sendKeys(searchhere);
		driver.findElement(By.xpath("//button[@aria-label='Search']")).click();	
		//driver.findElement(By.partialLinkText("tops and tees")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("option-label-size-143-item-170")).click();  	
		Thread.sleep(2000);
		driver.findElement(By.id("option-label-color-93-item-57")).click();
		}
	/*public void AddToCart(WebDriver driver) throws InterruptedException
	{
		driver.findElement(By.xpath("//div[@class='products wrapper grid products-grid']//div[3]//div[1]//div[1]//form[1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@class='action showcart']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@class='action edit']")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("option-label-size-143-item-168")).click();  	
		Thread.sleep(2000);
		driver.findElement(By.id("option-label-color-93-item-56")).click();
		Thread.sleep(2000);
		//driver.findElement(By.id("qty")).sendKeys("2");
		Thread.sleep(2000);
		driver.findElement(By.id("product-updatecart-button")).click();
	}*/
	public void welcomePujaKumari(WebDriver driver)
	 {
		 driver.findElement(By.xpath("//span[@aria-expanded='false']")).click();
	 }
	 public void signout(WebDriver driver)
	 {
		 driver.findElement(By.partialLinkText("Sign")).click();
	 }
	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Kunal\\Documents\\Automation\\chromedriver-win32\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
        
        Luma_SearchForProduct l= new  Luma_SearchForProduct();
        
        l.url(driver);
        l.maximize(driver);
        l.cookies(driver);
        Thread.sleep(2000);
        l.newuser(driver);
        Thread.sleep(2000);
        l.signin(driver);
        l.searchhere(driver, "Tops" );
    	Thread.sleep(2000);
    	l.welcomePujaKumari(driver);
    	Thread.sleep(2000);
    	l.signout(driver);
    	Thread.sleep(2000);
    	driver.close();
}
}