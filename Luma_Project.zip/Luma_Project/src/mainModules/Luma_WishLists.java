package mainModules;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Luma_WishLists 
{
	public void url(WebDriver driver)
	{
       driver.get("https://magento.softwaretestingboard.com");
	}
public void maximize(WebDriver driver)
    {
	  driver.manage().window().maximize();
    }
public void cookies(WebDriver driver)
	{
		driver.manage().deleteAllCookies();
	}
public void newuser(WebDriver driver) throws InterruptedException
	{
		driver.findElement(By.partialLinkText("Create an")).click();
		driver.findElement(By.id("firstname")).sendKeys("Prachi");
		//Thread.sleep(2000);
		driver.findElement(By.id("lastname")).sendKeys("Singh");
		//Thread.sleep(2000);
		driver.findElement(By.id("email_address")).sendKeys("myselfparachi@gmail.com");
		//Thread.sleep(2000);
		driver.findElement(By.id("password")).sendKeys("Family@143");
		//Thread.sleep(2000);
		driver.findElement(By.id("password-confirmation")).sendKeys("Family@143");
	//	Thread.sleep(2000);
		driver.findElement(By.partialLinkText("Create an")).click();
	}
public void signin(WebDriver driver) throws InterruptedException
	{
		driver.findElement(By.partialLinkText("Sign")).click();  
		driver.findElement(By.id("email")).sendKeys("myselfparachi@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.id("pass")).sendKeys("Family@143");
		Thread.sleep(2000);
		driver.findElement(By.id("send2")).click();
		driver.findElement(By.xpath("//a[@aria-label='store logo']//img")).click();
	}
	public void wishlists(WebDriver driver) throws InterruptedException
	{
		String searchhere= JOptionPane.showInputDialog("Search Here");
		driver.findElement(By.id("search")).sendKeys(searchhere);
		driver.findElement(By.xpath("//button[@aria-label='Search']")).click();	
		//driver.findElement(By.partialLinkText("tops for")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("option-label-size-143-item-168")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("option-label-color-93-item-60")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//main[@id='maincontent']//div[4]//div[1]//div[2]//a[1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[@aria-expanded='false']")).click();
		Thread.sleep(2000);
		driver.findElement(By.partialLinkText("My Wish")).click();
	}
	public void welcomePujaKumari(WebDriver driver)
	 {
		 driver.findElement(By.xpath("//span[@aria-expanded='false']")).click();
	 }
	 public void signout(WebDriver driver)
	 {
		 driver.findElement(By.partialLinkText("Sign")).click();
	 }
	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Kunal\\Documents\\Automation\\chromedriver-win32\\chromedriver.exe");
		WebDriver driver =new EdgeDriver();
        
        Luma_WishLists l= new  Luma_WishLists();
        
        l.url(driver);
        l.maximize(driver);
        l.cookies(driver);
        Thread.sleep(2000);
        l.newuser(driver);
        Thread.sleep(2000);
        l.signin(driver);
       // l.searchhere(driver, "Tops" );
    	Thread.sleep(2000);
    	l.wishlists(driver);
    	Thread.sleep(2000);
      l.welcomePujaKumari(driver);
      Thread.sleep(2000);
      l.signout(driver);
      driver.close();

	}

}
